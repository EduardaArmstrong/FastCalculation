package br.edu.ifsp.scl.fastcalculation

object Extras {
    const val EXTRA_SETTINGS = "EXTRA_SETTINGS"
}