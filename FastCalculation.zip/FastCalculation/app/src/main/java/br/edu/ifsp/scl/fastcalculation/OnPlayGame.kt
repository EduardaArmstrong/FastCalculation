package br.edu.ifsp.scl.fastcalculation

interface OnPlayGame {
    fun onPlayGame()
}